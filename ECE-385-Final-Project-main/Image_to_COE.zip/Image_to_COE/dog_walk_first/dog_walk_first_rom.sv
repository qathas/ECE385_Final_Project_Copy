module dog_walk_first_rom (
	input logic clock,
	input logic [13:0] address,
	output logic [3:0] q
);

logic [3:0] memory [0:9349] /* synthesis ram_init_file = "./dog_walk_first/dog_walk_first.COE" */;

always_ff @ (posedge clock) begin
	q <= memory[address];
end

endmodule
