module num_5_rom (
	input logic clock,
	input logic [8:0] address,
	output logic [3:0] q
);

logic [3:0] memory [0:319] /* synthesis ram_init_file = "./num_5/num_5.COE" */;

always_ff @ (posedge clock) begin
	q <= memory[address];
end

endmodule
