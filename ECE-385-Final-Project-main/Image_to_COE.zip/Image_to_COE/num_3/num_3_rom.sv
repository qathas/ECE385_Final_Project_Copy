module num_3_rom (
	input logic clock,
	input logic [8:0] address,
	output logic [3:0] q
);

logic [3:0] memory [0:319] /* synthesis ram_init_file = "./num_3/num_3.COE" */;

always_ff @ (posedge clock) begin
	q <= memory[address];
end

endmodule
