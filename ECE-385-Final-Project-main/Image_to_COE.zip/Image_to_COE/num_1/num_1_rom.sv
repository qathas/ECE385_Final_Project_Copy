module num_1_rom (
	input logic clock,
	input logic [6:0] address,
	output logic [3:0] q
);

logic [3:0] memory [0:79] /* synthesis ram_init_file = "./num_1/num_1.COE" */;

always_ff @ (posedge clock) begin
	q <= memory[address];
end

endmodule
