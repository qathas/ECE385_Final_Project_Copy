module duckhunt_rightfacing_wingup_rom (
	input logic clock,
	input logic [9:0] address,
	output logic [3:0] q
);

logic [3:0] memory [0:1023] /* synthesis ram_init_file = "./duckhunt_rightfacing_wingup/duckhunt_rightfacing_wingup.COE" */;

always_ff @ (posedge clock) begin
	q <= memory[address];
end

endmodule
