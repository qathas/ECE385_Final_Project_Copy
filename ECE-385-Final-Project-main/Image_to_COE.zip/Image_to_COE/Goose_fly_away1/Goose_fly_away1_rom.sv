module Goose_fly_away1_rom (
	input logic clock,
	input logic [11:0] address,
	output logic [3:0] q
);

logic [3:0] memory [0:3135] /* synthesis ram_init_file = "./Goose_fly_away1/Goose_fly_away1.COE" */;

always_ff @ (posedge clock) begin
	q <= memory[address];
end

endmodule
