module dog_laugh1_rom (
	input logic clock,
	input logic [13:0] address,
	output logic [3:0] q
);

logic [3:0] memory [0:9349] /* synthesis ram_init_file = "./dog_laugh1/dog_laugh1.COE" */;

always_ff @ (posedge clock) begin
	q <= memory[address];
end

endmodule
